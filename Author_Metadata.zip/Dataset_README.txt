There are 76 unique LastName_FirstInitial dataset available at https://github.com/Yonsei-TSMM/author_name_disambiguation.
There are 75 excel sheets more like the one which is present here.
We will upload these excel sheet very soon.